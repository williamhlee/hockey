import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.poifs.filesystem.FileMagic;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Name;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	private static final int LAST_CELL = 69;
	private static final int LAST_ROW = 24;
    private static final Pattern PATTERN = Pattern.compile("^([A-Z]+)(\\d+)$");
    boolean seriesFinished[]= new boolean[16];
	private Map<String, Person> allPicks = new HashMap();
	private Map<String, Double> winnersList = new HashMap();
	private Map<String, Double> winnersCount = new HashMap();
//	private Map<String, String> uniqueWinners = new HashMap();
	private Map<Integer, Map<String, String>> uniqueWinnersRound = new HashMap();
	private Person winner;
	private Person team1;
	private Person team2;
	private int numOfRuns = 0;
	private int numOfResluts = 0;
	private int highScore = 0;
	double highScoreCount = 0.0;
	int games = 0;
	double startTime = System.currentTimeMillis();
	double startTime2;
	double startTime3;
	double winnerTime = 0.0;
	double scoreTime = 0.0;
	
    public ExcelReader(String filePath) throws InvalidFormatException, IOException {
        this(filePath, true);
    }
 
    public ExcelReader(String filePath, boolean ignoreFormula) throws InvalidFormatException, IOException {
		System.out.println("Start: " + (new java.util.Date()) );
    	String team = "";
    	
        try {

            FileInputStream excelFile = new FileInputStream(new File(filePath));
            XSSFWorkbook workbook = new XSSFWorkbook(excelFile);
            Sheet datatypeSheet = workbook.getSheetAt(0);
            Cell currentCell;
            int round = 0;
            
            for (int col = 0; col < LAST_CELL; col += 2) {
//            	System.out.println("Starting col " + col);
            	currentCell = datatypeSheet.getRow(0).getCell(col);
            	if (currentCell != null && currentCell.getStringCellValue().compareTo("")!=0) {
	            	Person person = new Person(currentCell.getStringCellValue());
	            	round = 0;
	            	for (int row = 1; row <= LAST_ROW; row++) {
//	                	System.out.println("Starting row " + row);
	                	currentCell = datatypeSheet.getRow(row).getCell(col);
	                	if (currentCell != null) {
	                		team = "";
	                		if (currentCell.getCellTypeEnum() == CellType.STRING && currentCell.getStringCellValue().compareTo("")!=0) {
	                			team = currentCell.getStringCellValue().trim();
//	                		} else if ((currentCell.getCellTypeEnum() == CellType.FORMULA)) {
//	                			team = currentCell.getStringCellValue();
//	                			team = currentCell.getRichStringCellValue().toString();
//	                		} else if ((currentCell.getCellTypeEnum() == CellType.FORMULA) && (currentCell.getNumericCellValue() >0 && currentCell.getRichStringCellValue().toString().compareTo("")!=0)) {
//	                			team = currentCell.getRichStringCellValue().toString();
	                		}
	                		if ((team.compareToIgnoreCase("Points") == 0) || (team.trim().compareToIgnoreCase("") == 0)){
	                			continue;
	                		}
	                		games = 0;
	                		if (datatypeSheet.getRow(row).getCell(col+1) != null && datatypeSheet.getRow(row).getCell(col+1).getCellTypeEnum() == CellType.NUMERIC) {
	                			games = (int) datatypeSheet.getRow(row).getCell(col+1).getNumericCellValue();
	                		}

//	                    	Pick pick = new Pick(person.getName(), datatypeSheet.getRow(row).getCell(col).getStringCellValue(), games);
	                    	Pick pick = new Pick(team, games, true, 0);
	                    	round++;
	                    	if ((person.getName().compareToIgnoreCase("Winner")!=0) && (person.getName().compareToIgnoreCase("team1")!=0) && (person.getName().compareToIgnoreCase("team2")!=0)) {
	                    		if (uniqueWinnersRound.get(round) != null) {
	                    			Map<String, String> uniqueWinners = uniqueWinnersRound.get(round);
		                    		if (uniqueWinners.get(team) == null) {
			                    		uniqueWinners.put(team, team);
			                    		uniqueWinnersRound.put(round, uniqueWinners);
			                    	}
	                    			
		                    	} else {
		                    		Map<String, String> uniqueWinners = new HashMap();
		                    		uniqueWinners.put(team, team);
		                    		uniqueWinnersRound.put(round, uniqueWinners);
		                    	}
	                    	}

	//	                	if (currentCell.getCellTypeEnum() == CellType.STRING) {
	//				        	System.out.print(currentCell.getStringCellValue() + "--");
	//				        } else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
	//				        	System.out.print(currentCell.getNumericCellValue() + "--");
	//				        }
//		                	System.out.println("processing row with a pick " + row);
		                	person.addPicks(round, pick);
		                	if (row != 0.0 && person.getName().compareToIgnoreCase("Winner")==0 && (pick.getTeam() != null)) {
		                		seriesFinished[round] = true;
	            				if (round<=8) {
	            					//round 1
	            					pick.setValue(2);
	            				} else if (round<=12) {
	            					//round 2
	            					pick.setValue(3);
	            				} else if (round<=14) {
	            					//round 3
	            					pick.setValue(4);
	            				} else {
	            					//round 4
	            					pick.setValue(5);
	            				}
		                	}
	                	}
//	                	System.out.println("Ending row " + row);
	                }
                	if (person.getName().compareToIgnoreCase("Winner")==0) {
                		int value = 0;
                        for (int i = person.getPicks().size(); i < 15; i++) {
            				if (i<8) {
            					//round 1
            					value = 2;
            				} else if (i<12) {
            					//round 2
            					value = 3;
            				} else if (i<14) {
            					//round 3
            					value = 4;
            				} else {
            					//round 4
            					value = 5;
            				}

	                    	Pick pick = new Pick("", 0, false, value);
	                    	person.getPicks().put(i+1, pick);
                        }
                		winner = person;
                	} else if (person.getName().compareToIgnoreCase("team1")==0) {
                        for (int i = person.getPicks().size(); i < 15; i++) {
	                    	Pick pick = new Pick("", 0, false, 0);
	                    	person.getPicks().put(i+1, pick);
                        }
                		team1 = person;
                	} else if (person.getName().compareToIgnoreCase("team2")==0) {
                        for (int i = person.getPicks().size(); i < 15; i++) {
	                    	Pick pick = new Pick("", 0, false, 0);
	                    	person.getPicks().put(i+1, pick);
                        }
                		team2 = person;
                	} else {
                		allPicks.put(person.getName(), person);
                	}
//		        	System.out.println(person);
//	                System.out.println(col);
            	}
//            	System.out.println("Ending col " + col);
            }
            
//            datatypeSheet.
            workbook.close();
            excelFile.close();
//			System.out.println("Done with Excel: " + (System.currentTimeMillis() - startTime)/1000 + " seconds");

    	    processSeries(1, 1, "");
    	    System.out.println("Done processing series: " + (System.currentTimeMillis() - startTime)/1000 + " seconds");
    	    System.out.println("winnerTime processing series: " + winnerTime/1000 + " seconds");
    	    System.out.println("scoreTime processing series: " + scoreTime/1000 + " seconds");
			
			for (Entry<String, Double> wl : winnersList.entrySet()) {
	        	System.out.println(wl.getKey() + "; " + wl.getValue() / numOfResluts + "; " + winnersCount.get(wl.getKey()));
        	}
//        	for (String name : winnersList.keySet()) {
//	        	System.out.println(name + "; " + winnersList.get(name) / numOfResluts + "; " + winnersCount.get(name));
//        	}

//        	for (Integer i = 1; i < 16; i++ ) {
//        		Map<String, String> uw = uniqueWinnersRound.get(i);
//        		for (String key : uw.keySet()) {
//            		System.out.println("round " + i + " " + key);
//            	}
//        	}

        	System.out.println("numOfRuns " + numOfRuns);
        	System.out.println("numOfResluts " + numOfResluts);
        	
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    	
    }

    private void processSeries(int series, int factor, String teamResults) {
	
    	int ser;
    	int minGame;
    	int localGame;
    	int localFactor;
		String localTeamResults = "";
		String team;
		int nextSeries = 0;
//		if (series >= 15) {
//			System.out.println("Starting processSeries " + series);
//		}

        for (ser = 1; ser <= 2; ser += 1) {
//	'        startTime1 = Timer
	        localFactor = factor;
	        if (seriesFinished[series]) {
	            ser = 3;
	            minGame = 7;
	        } else {
//	            if (firstUnfinishedSeries == 0) {
//	                firstUnfinishedSeries = series;
//	            } else if (secondUnfinishedSeries == 0) {
//	                secondUnfinishedSeries = series;
//	            }
//	            teamName = Sheets("All Picks").Cells(seriesTeam1Row(series), ser).Value
//	            Sheets("All Picks").Cells(seriesTeam1Row(series), seriesColumn(series)).Value = teamName

            	nextSeries = 0;
            	if (series == 1 || series == 2) {
            		nextSeries = 9;
            	} else if (series == 3 || series == 4) {
            		nextSeries = 10;
            	} else if (series == 5 || series == 6) {
            		nextSeries = 11;
            	} else if (series == 7 || series == 8) {
            		nextSeries = 12;
            	} else if (series == 9 || series == 10) {
            		nextSeries = 13;
            	} else if (series == 11 || series == 12) {
            		nextSeries = 14;
            	} else if (series == 13 || series == 14) {
            		nextSeries = 15;
            	}
            	minGame = 0;
        		if (ser == 1) {
	            	minGame = team1.getPicks().get(series).getGames();
	            	team = team1.getPicks().get(series).getTeam();
	            	winner.getPicks().get(series).setTeam(team);
        		} else {
	            	minGame = team2.getPicks().get(series).getGames();
	            	team = team2.getPicks().get(series).getTeam();
	            	winner.getPicks().get(series).setTeam(team);
        		}

        		if ((series & 1) == 0) {
	            	if (nextSeries != 0) {
            			team2.getPicks().get(nextSeries).setTeam(team);
	            		team2.getPicks().get(nextSeries).setGames(4);
	            	}
            	} else {
	            	if (nextSeries != 0) {
            			team1.getPicks().get(nextSeries).setTeam(team);
	            		team1.getPicks().get(nextSeries).setGames(4);
	            	}
            	}

	            if (minGame == 0) {
	                minGame = 4;
	            }

	            //this is if no one picks the team at all
	            if (uniqueWinnersRound.get(series).get(team) == null) {
	                if (localFactor == 1) {
	                    localFactor = 8 - minGame; //4
	                } else {
	                    localFactor = localFactor * (8 - minGame); //4
	                }
	                minGame = 7;
//	                Debug.Print "skipping " & teamName, series, factor, localFactor
	            }
	        
	        }

			//loop through the remaining games in the series for calculating the winner
	        for (int game = minGame; game <= 7; game++) {
	            if (!seriesFinished[series]) {
            		winner.getPicks().get(series).setGames(game);
	            }
				
	            localGame = winner.getPicks().get(series).getGames();
	
	            if (series == 15) {
	            	double hits = 0.0;
	            	double oldScore = 0.0;
//		            System.out.println("series = " + series + " ser = " + ser + " team = " + winner.getPicks().get(series).getTeam() + " game = " + winner.getPicks().get(series).getGames());

	        		startTime2 = System.currentTimeMillis();
	        		highScore = score();
	        		winnerTime = winnerTime + System.currentTimeMillis() - startTime2;
	        				
//	                for (String name : allPicks.keySet()) {
	                for (Entry<String, Person> n : allPicks.entrySet()) {
//            			Person p = allPicks.get(name);
        		        if (n.getValue().getPotentialPoints() == highScore) {
        		            hits = hits + 1;
        		            if (winnersList.containsKey(n.getKey())) {
        		                oldScore = winnersList.get(n.getKey());
        		                winnersList.put(n.getKey(), oldScore + (1 / highScoreCount) * localFactor);
        		            	winnersCount.put(n.getKey(), winnersCount.get(n.getKey()) + (1 / highScoreCount) * localFactor);
//        			            System.out.println("name = " + name + " 1 / highScoreCount = " + 1 / highScoreCount);
//        	    				if (name.compareToIgnoreCase("TNelson") == 0) {
//        	    	    			System.out.println(name + " " + winner);
//        	    				}
        		            } else {
        		                winnersList.put(n.getKey(), (double) ((1 / highScoreCount) * localFactor));
        		            	winnersCount.put(n.getKey(), (double) (1 / highScoreCount) * localFactor);
//        			            System.out.println("name = " + name + " 1 / highScoreCount = " + 1 / highScoreCount);
//        	    				if (name.compareToIgnoreCase("TNelson") == 0) {
//        	    	    			System.out.println(name + " " + winner);
//        	    				}
        		            }
//            		        if (hits >= highScoreCount) {
//            		        	break;
//            		        }
            		        if ((hits - highScoreCount) >= 0.0) {
            		        	break;
            		        }
        		        }
	        		
	            	}

	                numOfRuns = numOfRuns + 1;
	                numOfResluts = numOfResluts + localFactor;
//		            System.out.println(winner + " numOfRuns = " + numOfRuns + " numOfResluts = " + numOfResluts );
	            } else {
	                if (!seriesFinished[series]) {
	                    if (teamResults.compareTo("")==0) {
	                        localTeamResults = winner.getPicks().get(series).getTeam() + " in " + localGame;
	                    } else {
	                        localTeamResults = teamResults + " : " + winner.getPicks().get(series).getTeam() + " in " + localGame;
	                    }
	                    
	                    //If no one picked the team?
//	                    if Application.WorksheetFunction.CountIf(seriesRange(series), winner.getPicks().get(series).getTeam()) = 0) {
//	                        localTeamResults = localTeamResults + "*"
//	                    }
	                }
	                
	                processSeries(series + 1, localFactor, localTeamResults);
	            }
	
	        }
	
	
        }
	
	}	
    

    private int score() {
    	highScore = 0;
    	highScoreCount = 0.0;

    	for (Entry<String, Person> p : allPicks.entrySet()) {
//    	for (String name : allPicks.keySet()) {

    			startTime3 = System.currentTimeMillis();
    			int score = p.getValue().score(winner);
        		scoreTime = scoreTime + System.currentTimeMillis() - startTime3;
    			if (score > highScore) {
    				highScore = score;
    				highScoreCount = 1.0;
    			} else if (score == highScore) {
    				highScore = score;
    				highScoreCount++;
    			}

    	}
    	return highScore;
    }
}
