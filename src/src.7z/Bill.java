
public class Bill {

	public static void main(String[] args) {
		
	}
}
