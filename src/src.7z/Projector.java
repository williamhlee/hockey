import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

public class Projector {


	public static void main(String[] args) {
		int cores = Runtime.getRuntime().availableProcessors();
		System.out.println("cores: " + cores);
		
		double startTime = System.currentTimeMillis();
		System.out.println("Start: " + (new java.util.Date()) );
		
		ExcelReader er = null;
		try {
			er = new ExcelReader("C:\\Users\\Bill-PC\\Desktop\\NHL 2017 Playoffs-factor - Java.xlsm");
//			int i = er.getRowNumber();
//			System.out.println("read");
			
		} catch (IOException ioe) {
			System.out.println(ioe);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			System.out.println("time it took: " + (System.currentTimeMillis() - startTime)/1000 + " seconds");
		}
	
	}	
	
}
