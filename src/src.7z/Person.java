import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Person {

	private String name = "";
	private Map<Integer, Pick> picks = new HashMap();

	private int points = 0;
	private int potentialPoints = 0;
	
	public Person(String n) {
		this.name = n;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<Integer, Pick> getPicks() {
		return picks;
	}

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	public int getPotentialPoints() {
		return potentialPoints;
	}

	public void setPotentialPoints(int potentialPoints) {
		this.potentialPoints = potentialPoints;
	}

	public void addPicks(int round, Pick p) {
		picks.put(round, p);
	}
	
	public int score(Person winner) {
		int score = 0;
//		for (Entry<Integer, Pick> pick : picks.entrySet()) {
//			if ((pick.getKey() <= 15) && (pick.getValue().getTeam().compareTo(winner.getPicks().get(pick.getKey()).getTeam())==0)) {
//				if (pick.getKey()<9) {
//					//round 1
//					score = score + 2;
//					if (pick.getValue().getGames() == (winner.getPicks().get(pick.getKey()).getGames())) {
//						score = score + 1;
//					}
//				} else if (pick.getKey()<13) {
//					//round 2
//					score = score + 3;
//					if (pick.getValue().getGames() == (winner.getPicks().get(pick.getKey()).getGames())) {
//						score = score + 1;
//					}
//				} else if (pick.getKey()<15) {
//					//round 3
//					score = score + 4;
//					if (pick.getValue().getGames() == (winner.getPicks().get(pick.getKey()).getGames())) {
//						score = score + 1;
//					}
//				} else {
//					//round 4
//					score = score + 5;
//					if (pick.getValue().getGames() == (winner.getPicks().get(pick.getKey()).getGames())) {
//						score = score + 1;
//					}
//				}
//			}
//		}

		for (int i = 1; i<16; i++) {
//			System.out.println(picks.get(i).getTeam() + " " + winner.getPicks().get(i).getTeam());
//			System.out.println(picks.get(i).getGames() + " " + winner.getPicks().get(i).getGames());
			if (picks.get(i).getTeam().compareTo(winner.getPicks().get(i).getTeam())==0) {
//				score = score + winner.getPicks().get(i).getValue();
				if (i<9) {
					//round 1
					score = score + 2;
				} else if (i<13) {
					//round 2
					score = score + 3;
				} else if (i<15) {
					//round 3
					score = score + 4;
				} else {
					//round 4
					score = score + 5;
				}
				if (picks.get(i).getGames() == (winner.getPicks().get(i).getGames())) {
					score = score + 1;
				}
			}
		}
		potentialPoints = score;
		return score;
	}

	public String toString() {
		String result = name;
		
        for (int round = 13; round <= picks.size(); round += 1) {
        	result = result + " round=" + round + " " + picks.get(round).toString() + ";";
        }
        
		return result;
	}
}
